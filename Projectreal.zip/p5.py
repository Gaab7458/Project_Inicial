numero_atrasos = int(input('Quantos atrasos você teve?: '))
if numero_atrasos == 0:
    print('Você nunca se atrasou, tudo bem. Pode entrar!')
elif numero_atrasos == 1:
        print ('Pode entrar, na proxima já sabe, você pode ter mais 2 faltas')
elif numero_atrasos ==2:
    print ('Pode entrar, na proximo já sabe,você pode ter mais 1 faltas')
elif numero_atrasos == 3:
    print ('Você está suspensa, atingiu o limite de faltas, teve 3')
elif numero_atrasos > 3:
    print('Precisamos chamar seus pais!')
    
    