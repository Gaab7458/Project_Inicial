# Escreva um programa que pergunte a quantidade de Km percorridos por um carro alugado e a quantidade de dias pelos quais ele foi alugado. Calcule o preço a pagar, sabendo que o carro custa R$60 por dia e R$0,15 por Km rodado.
d = int(input('Digite por quantos dias você alugou o seu carro: '))
kmr = float(input('Digite por quantos KMs você rodou com carro: '))
vpd = d * 60
vpk = kmr * 0.15
vt = vpd + vpk
print('Olá Homosapiem, tudo vem? Você terá que pegar {:.2f}, já que alugou por {} dias e andou por {}km'.format(vt,d,kmr))
