import random

valor_aleatorio = random.randint(0, 10)
acertou = False
while acertou == False:
    chute = int(input('Chute um valor de 0 a 10: '))
    if chute > valor_aleatorio:
        print('Você colocou um valor maior do que o gerado! Tente novamente')
    elif chute < valor_aleatorio:
        print('Você colocou um número menor do que o gerado! Tente novamente')
    elif chute == valor_aleatorio:
        acertou = True
        print('Boa,Você acertou!')

