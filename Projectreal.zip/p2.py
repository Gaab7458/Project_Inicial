#Promoção ---> 15% de aumento com base no salario atual
s = float(input('Digite seu salário: '))
ps = s*15/100
ns = s+ps
print('Como acordado seu salário atual {:.3f} vai passar por um aumento de 15% e parasá a ser {:.3f}'.format(s,ns))
